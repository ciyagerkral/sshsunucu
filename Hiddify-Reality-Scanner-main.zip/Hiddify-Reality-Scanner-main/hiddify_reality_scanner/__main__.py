"""Entry point for hiddify_reality_scanner."""

from hiddify_reality_scanner.cli import main  # pragma: no cover

if __name__ == "__main__":  # pragma: no cover
    main()
