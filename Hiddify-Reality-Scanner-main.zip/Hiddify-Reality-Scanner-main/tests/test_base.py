from hiddify_reality_scanner.base import NAME


def test_base():
    assert NAME == "hiddify_reality_scanner"
